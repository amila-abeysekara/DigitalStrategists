<?php

return [
    'standard', 'neural'
];
