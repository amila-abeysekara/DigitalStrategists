<?php

return [
    'english' => 'English',
];
