<?php

/* Configuration of the site */
// define('DATABASE_SERVER',   'localhost');
// define('DATABASE_USERNAME', 'root');
// define('DATABASE_PASSWORD', '');
// define('DATABASE_NAME',     'AI');
// define('SITE_URL',          'http://localhost/product/');
define('DATABASE_SERVER',   'localhost');
define('DATABASE_USERNAME', 'awsstart_digitalstrategistsco_gen_ai');
define('DATABASE_PASSWORD', 'TxYrjrfjN64M98j2T9c4');
define('DATABASE_NAME',     'awsstart_digitalstrategistsco_gen_ai');
define('SITE_URL',          'https://digitalstrategists.co/');
